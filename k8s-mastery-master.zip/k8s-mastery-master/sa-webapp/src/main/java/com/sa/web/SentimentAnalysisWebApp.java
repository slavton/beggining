package com.sa.web;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SentimentAnalysisWebApp {

	public static void main(String[] args) {
		SpringApplication.run(SentimentAnalysisWebApp.class, args);
	}
}
